---
name: Calendar Picker – stan projektu
description: Polski picker daty/godziny jako strona HTML i wtyczka Firefox sidebar
type: project
---

Projekt to narzędzie do szybkiego kopiowania daty i przedziału godzinowego w formacie `DD.MM.YYYY (dzień_tygodnia) HH:MM-HH:MM` (np. do kalendarza / maili).

**Pliki:**
- `index.html` — samodzielna strona (otworzyć w przeglądarce)
- `firefox-extension/` — wtyczka Firefox (Manifest V2, sidebar_action)
  - `manifest.json`, `sidebar.html`, `icons/icon.svg`
- `calendar-picker.zip` — spakowana wtyczka gotowa do wgrania

**Stan na 2026-05-21:** wszystko gotowe i skomitwane. Wtyczka działa jako boczny panel (sidebar) w Firefox.

**How to apply:** Przy powrocie — projekt gotowy, ewentualne dalsze prace to np. MV3, podpisanie wtyczki, dodanie skrótu klawiaturowego do otwierania sidebara.
